
def cli():
    print('Hello client')
